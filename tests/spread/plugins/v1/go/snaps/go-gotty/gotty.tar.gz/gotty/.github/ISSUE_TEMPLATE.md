# When file a bug report (see below for feature requests)

Please answer these quesions for a bug report. Thanks!

### What version of GoTTY are you using (`gotty --version`)?


### What operating system and browser are you using?


### What did you do?

If possible, please provide the command you ran.


### What did you expect to see?


### What did you see instead?

If possible, please provide the output of the command and your browser's console output.



# When file a new feature proposal

Please provide an actual usecase that requires your new feature.
