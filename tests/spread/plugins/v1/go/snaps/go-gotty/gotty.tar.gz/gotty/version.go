package main

var Version = "unknown_version"
var CommitID = "unknown_commit"
