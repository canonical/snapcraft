// Package webtty provides a protocl and an implementation to
// controll terminals thorough networks.
package webtty
