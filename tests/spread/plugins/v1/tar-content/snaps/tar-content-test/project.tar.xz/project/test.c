#include <stdio.h>
int main() {
    printf("tarproject\n");
}
