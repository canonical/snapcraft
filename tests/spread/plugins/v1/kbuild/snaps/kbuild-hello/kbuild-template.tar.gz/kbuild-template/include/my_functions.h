/*
 * Copyright (C) 2016 by Ole Reinhardt <ole.reinhardt@embedded-it.de>
 *
 * All rights reserved.
 *
 * For additional licensing information see COPYING.myapp
 */

#ifndef _MY_FUNCTIONS_H_
#define _MY_FUNCTIONS_H_

extern void my_sample_function(void);

#endif /* _MY_FUNCTIONS_H_ */
